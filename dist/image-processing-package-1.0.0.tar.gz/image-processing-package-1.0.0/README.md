# image-processing-package

Descrição.

O pacote `image-processing-package` é usado para:
	- Histrogram matching
	- Sructural similatity
	- Resize image
Utils:
	- Read image
	- Save image
	- Plot image
	- Plot result
	- Plot histogram

## Instalação

Use o gerenciador de pacotes [pip](https://pip.pypa.io/en/stable/) para instalar `image-processing-package`.

```bash
pip install image-processing-package

Contribuição
Contribuições são bem-vindas! Sinta-se à vontade para abrir um Pull Request com correções, melhorias ou novas funcionalidades.
 
Licença
Este pacote é licenciado sob a Licença MIT.